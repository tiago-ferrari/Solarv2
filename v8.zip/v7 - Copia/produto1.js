document.addEventListener('DOMContentLoaded', function() {
    // Código JavaScript específico para a página do produto
  });
  